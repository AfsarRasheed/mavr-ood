#!/usr/bin/env python3
"""
MAVR-OOD Gradio Frontend
Multi-Agent Visual Reasoning for Out-of-Distribution Object Detection

Two tabs:
  1. Text-Guided Detection — user provides text prompt to detect specific objects
  2. OOD Detection — upload a road scene image, run full OOD pipeline
"""

import os
import sys
import json
import numpy as np
import torch
import cv2
import gradio as gr
from PIL import Image
import matplotlib
matplotlib.use('Agg')

# ============================================================
# Model loading — imported from src/model_loader.py
# (monkey-patch, path setup, and singleton loaders all live there)
# ============================================================
from src.model_loader import (
    load_gdino_model,
    load_sam_predictor,
    load_clip_verifier,
    get_device,
    DEVICE,
)
import matplotlib.pyplot as plt

# Add paths for GroundingDINO imports used in this file
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "GroundingDINO"))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "segment_anything"))

import GroundingDINO.groundingdino.datasets.transforms as T
from GroundingDINO.groundingdino.util.utils import get_phrases_from_posmap
from segment_anything import SamPredictor

# Default paths for dataset
DEFAULT_DATASET_DIR = "./data/challenging_subset"


# =====================
# Core Pipeline
# =====================
def preprocess_image(image_pil):
    """Preprocess image for GroundingDINO."""
    transform = T.Compose([
        T.RandomResize([800], max_size=1333),
        T.ToTensor(),
        T.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225]),
    ])
    image_tensor, _ = transform(image_pil, None)
    return image_tensor


def get_grounding_output(model, image_tensor, caption, box_threshold=0.3, text_threshold=0.25):
    """Run GroundingDINO detection."""
    caption = caption.lower().strip()
    if not caption.endswith("."):
        caption += "."

    image_tensor = image_tensor.to(DEVICE)
    with torch.no_grad():
        outputs = model(image_tensor[None], captions=[caption])

    logits = outputs["pred_logits"].cpu().sigmoid()[0]
    boxes = outputs["pred_boxes"].cpu()[0]

    filt_mask = logits.max(dim=1)[0] > box_threshold
    logits_filt = logits[filt_mask]
    boxes_filt = boxes[filt_mask]

    tokenizer = model.tokenizer
    tokenized = tokenizer(caption)

    pred_phrases = []
    scores = []
    for logit, box in zip(logits_filt, boxes_filt):
        pred_phrase = get_phrases_from_posmap(logit > text_threshold, tokenized, tokenizer)
        score = logit.max().item()
        pred_phrases.append(f"{pred_phrase}({score:.2f})")
        scores.append(score)

    return boxes_filt, pred_phrases, scores


def run_sam_segmentation(predictor, image_np, boxes):
    """Run SAM segmentation on detected boxes."""
    predictor.set_image(image_np)
    H, W = image_np.shape[:2]

    # Scale boxes from [0,1] to image size
    boxes_scaled = boxes.clone()
    boxes_scaled[:, 0] *= W  # x_center
    boxes_scaled[:, 1] *= H  # y_center
    boxes_scaled[:, 2] *= W  # width
    boxes_scaled[:, 3] *= H  # height

    # Convert from cxcywh to xyxy
    boxes_xyxy = torch.zeros_like(boxes_scaled)
    boxes_xyxy[:, 0] = boxes_scaled[:, 0] - boxes_scaled[:, 2] / 2
    boxes_xyxy[:, 1] = boxes_scaled[:, 1] - boxes_scaled[:, 3] / 2
    boxes_xyxy[:, 2] = boxes_scaled[:, 0] + boxes_scaled[:, 2] / 2
    boxes_xyxy[:, 3] = boxes_scaled[:, 1] + boxes_scaled[:, 3] / 2

    transformed_boxes = predictor.transform.apply_boxes_torch(
        boxes_xyxy.to(DEVICE), (H, W)
    )

    masks, _, _ = predictor.predict_torch(
        point_coords=None,
        point_labels=None,
        boxes=transformed_boxes,
        multimask_output=False,
    )

    return masks.cpu(), boxes_xyxy


def create_detection_visualization(image_np, boxes_xyxy, labels):
    """Create image with bounding boxes drawn."""
    vis = image_np.copy()
    for box, label in zip(boxes_xyxy, labels):
        x1, y1, x2, y2 = box.int().numpy()
        cv2.rectangle(vis, (x1, y1), (x2, y2), (0, 255, 0), 3)
        cv2.putText(vis, label, (x1, max(y1 - 10, 0)),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
    return vis


def create_mask_visualization(image_np, masks):
    """Create image with SAM segmentation masks overlaid."""
    vis = image_np.copy().astype(np.float32)
    colors = [
        [255, 0, 100],   # pink
        [255, 165, 0],   # orange
        [0, 255, 255],   # cyan
        [255, 255, 0],   # yellow
        [128, 0, 255],   # purple
    ]
    for i, mask in enumerate(masks):
        mask_np = mask.squeeze().numpy().astype(bool)
        color = np.array(colors[i % len(colors)], dtype=np.float32)
        vis[mask_np] = vis[mask_np] * 0.4 + color * 0.6
    return vis.astype(np.uint8)


def create_binary_mask_visualization(image_np, masks):
    """Create image with combined binary mask (pink overlay like reference)."""
    vis = image_np.copy().astype(np.float32)
    combined_mask = np.zeros(image_np.shape[:2], dtype=bool)
    for mask in masks:
        combined_mask |= mask.squeeze().numpy().astype(bool)
    pink = np.array([255, 105, 180], dtype=np.float32)
    vis[combined_mask] = vis[combined_mask] * 0.35 + pink * 0.65
    return vis.astype(np.uint8)

def show_mask(mask, ax, random_color=False):
    if random_color:
        color = np.concatenate([np.random.random(3), np.array([0.6])], axis=0)
    else:
        color = np.array([30/255, 144/255, 255/255, 0.6])
    h, w = mask.shape[-2:]
    mask_image = mask.reshape(h, w, 1) * color.reshape(1, 1, -1)
    ax.imshow(mask_image)

def show_box(box, ax, label):
    x0, y0 = box[0], box[1]
    w, h = box[2] - box[0], box[3] - box[1]
    ax.add_patch(plt.Rectangle((x0, y0), w, h, edgecolor='green', facecolor=(0,0,0,0), lw=2))
    ax.text(x0, y0, label)

def generate_pipeline_visualization_img(image, anomaly_reasoning, v1_prompt, v2_prompt, boxes, clip_scores, masks):
    """Generates the 3-panel pipeline visualization as an RGB numpy array for Gradio."""
    try:
        import textwrap
        import io
        fig, axes = plt.subplots(1, 3, figsize=(24, 8))
        
        # Panel A
        ax1 = axes[0]
        ax1.imshow(image)
        ax1.axis('off')
        ax1.set_title("Panel A: Input + VLM Reasoning", fontsize=16, pad=10, weight='bold')
        reasoning_text = f"Agent 5 Reasoning:\n{anomaly_reasoning}\n\nGenerated Prompts:\nV1: '{v1_prompt}' | V2: '{v2_prompt}'"
        wrapped_text = "\n".join(textwrap.wrap(reasoning_text, width=60))
        ax1.text(0.5, -0.1, wrapped_text, ha='center', va='top', transform=ax1.transAxes, 
                 fontsize=14, bbox=dict(facecolor='white', alpha=0.8, edgecolor='gray'))

        # Panel B
        ax2 = axes[1]
        ax2.imshow(image)
        for i, box in enumerate(boxes):
            clip_score = clip_scores[i] if i < len(clip_scores) else 0.0
            label = f"Score: {clip_score:.3f}"
            show_box(box.numpy() if hasattr(box, 'numpy') else box, ax2, label)
        ax2.axis('off')
        ax2.set_title("Panel B: GroundingDINO + CLIP Verifier", fontsize=16, pad=10, weight='bold')

        # Panel C
        ax3 = axes[2]
        ax3.imshow(image)
        for mask in masks:
            mask_arr = mask.cpu().numpy() if hasattr(mask, 'cpu') else mask
            show_mask(mask_arr, ax3, random_color=True)
        ax3.axis('off')
        ax3.set_title("Panel C: Final SAM Segmentation", fontsize=16, pad=10, weight='bold')
                 
        plt.tight_layout(pad=3.0)
        
        # Save to buffer and convert to numpy array for Gradio
        buf = io.BytesIO()
        fig.savefig(buf, format="jpg", bbox_inches="tight", dpi=150)
        buf.seek(0)
        img_arr = np.array(Image.open(buf))
        plt.close(fig)
        return img_arr
    except Exception as e:
        print(f"Visualization error: {e}")
        return image



# =====================
# Agent Pipeline
# =====================
def run_agents_on_image(image_path):
    """Run all 5 agents on a single image and return analysis + prompts."""
    from src.agents.vlm_backend import run_vlm

    results = {}

    # Agent 1: Scene Context
    try:
        from src.agents.agent1 import SceneContextAnalyzer
        agent1 = SceneContextAnalyzer()
        results["agent1"] = agent1.analyze_image(image_path)
    except Exception as e:
        results["agent1"] = {"error": str(e)}

    # Agent 2: Spatial Anomaly
    try:
        from src.agents.agent2 import SpatialAnomalyDetector
        agent2 = SpatialAnomalyDetector()
        results["agent2"] = agent2.analyze_image(image_path)
    except Exception as e:
        results["agent2"] = {"error": str(e)}

    # Agent 3: Semantic Inconsistency
    try:
        from src.agents.agent3 import SemanticInconsistencyAnalyzer
        agent3 = SemanticInconsistencyAnalyzer()
        results["agent3"] = agent3.analyze_image(image_path)
    except Exception as e:
        results["agent3"] = {"error": str(e)}

    # Agent 4: Visual Appearance
    try:
        from src.agents.agent4 import VisualAppearanceEvaluator
        agent4 = VisualAppearanceEvaluator()
        results["agent4"] = agent4.analyze_image(image_path)
    except Exception as e:
        results["agent4"] = {"error": str(e)}

    # Agent 5: Synthesis
    try:
        from src.agents.agent5 import ReasoningSynthesizer
        agent5 = ReasoningSynthesizer()
        # Build combined dict with keys agent5 expects
        combined = {
            "agent1_scene_context": results.get("agent1", {}),
            "agent2_spatial_anomaly": results.get("agent2", {}),
            "agent3_semantic_inconsistency": results.get("agent3", {}),
            "agent4_visual_appearance": results.get("agent4", {}),
        }
        synthesis = agent5.synthesize_analysis(combined)
        results["agent5"] = synthesis
    except Exception as e:
        results["agent5"] = {"error": str(e)}

    return results


def extract_prompts(agent_results):
    """Extract prompt_v1 and prompt_v2 from agent 5 results."""
    a5 = agent_results.get("agent5", {})
    prompts = a5.get("grounded_sam_prompts", {})
    prompt_v1 = prompts.get("prompt_v1", a5.get("detailed_prompt", "unusual object on road"))
    prompt_v2 = prompts.get("prompt_v2", a5.get("simple_prompt", "anomaly"))
    return prompt_v1, prompt_v2


# =====================
# Single Image Pipeline
# =====================
def process_single_image(image, clip_threshold, box_threshold, progress=gr.Progress()):
    """Full pipeline for a single uploaded image."""
    if image is None:
        return None, None, None, "Please upload an image."

    progress(0.05, desc="Saving uploaded image...")

    # Save uploaded image temporarily
    tmp_path = os.path.join("outputs", "temp_upload.jpg")
    os.makedirs("outputs", exist_ok=True)
    if isinstance(image, np.ndarray):
        image_pil = Image.fromarray(image)
    else:
        image_pil = image
    image_pil.save(tmp_path)
    image_np = np.array(image_pil)

    # Stage 1: Run agents
    progress(0.1, desc="[i] Running Agent 1: Scene Context...")
    agent_results = run_agents_on_image(tmp_path)
    
    # Extract reasoning for visualizations
    a5_data = agent_results.get("agent5", {})
    reasoning = a5_data.get('anomaly_reasoning', a5_data.get('reasoning', 'No reasoning generated.'))

    progress(0.5, desc="[*] Extracting prompts...")
    prompt_v1, prompt_v2 = extract_prompts(agent_results)

    # Stage 2: GroundingDINO Detection
    progress(0.55, desc="[i] Loading GroundingDINO + SAM...")
    gdino = load_gdino_model()
    predictor = load_sam_predictor()
    clip_verifier = load_clip_verifier()

    progress(0.65, desc=f"[>] Detecting with prompt: '{prompt_v1}'...")
    image_tensor = preprocess_image(image_pil)

    # Try prompt_v1
    boxes, labels, scores = get_grounding_output(
        gdino, image_tensor, prompt_v1,
        box_threshold=box_threshold, text_threshold=0.25
    )

    # If no detections with v1, try v2
    if len(boxes) == 0 and prompt_v2 != prompt_v1:
        progress(0.7, desc=f"[>] Trying prompt_v2: '{prompt_v2}'...")
        boxes, labels, scores = get_grounding_output(
            gdino, image_tensor, prompt_v2,
            box_threshold=box_threshold, text_threshold=0.25
        )

    # CLIP verification
    clip_scores_final = []
    if len(boxes) > 0:
        progress(0.75, desc="[OK] CLIP verification...")
        try:
            # First convert GroundingDINO boxes (cxcywh normalized) to pixel xyxy for CLIP
            H, W = image_np.shape[:2]
            clip_boxes = boxes.clone()
            clip_boxes[:, 0] = (boxes[:, 0] - boxes[:, 2] / 2) * W
            clip_boxes[:, 1] = (boxes[:, 1] - boxes[:, 3] / 2) * H
            clip_boxes[:, 2] = (boxes[:, 0] + boxes[:, 2] / 2) * W
            clip_boxes[:, 3] = (boxes[:, 1] + boxes[:, 3] / 2) * H

            clip_verifier.similarity_threshold = clip_threshold
            filtered_boxes, filtered_phrases, clip_scores, _ = clip_verifier.verify_detections(
                image_np, clip_boxes, labels, prompt_v1
            )
            clip_scores_final = clip_scores
            if len(filtered_boxes) > 0:
                # Convert back to normalized cxcywh for SAM pipeline
                boxes_back = torch.zeros(len(filtered_boxes), 4)
                boxes_back[:, 0] = ((filtered_boxes[:, 0] + filtered_boxes[:, 2]) / 2) / W
                boxes_back[:, 1] = ((filtered_boxes[:, 1] + filtered_boxes[:, 3]) / 2) / H
                boxes_back[:, 2] = (filtered_boxes[:, 2] - filtered_boxes[:, 0]) / W
                boxes_back[:, 3] = (filtered_boxes[:, 3] - filtered_boxes[:, 1]) / H
                boxes = boxes_back
                labels = filtered_phrases
                
        except Exception as e:
            print(f"CLIP verification warning: {e}")

    # SAM Segmentation
    if len(boxes) > 0:
        progress(0.8, desc="[>] Running SAM segmentation...")
        masks, boxes_xyxy = run_sam_segmentation(predictor, image_np, boxes)

        progress(0.9, desc="[i] Creating visualizations...")
        detection_img = create_detection_visualization(image_np, boxes_xyxy, labels)
        mask_img = create_mask_visualization(image_np, masks)
        binary_img = create_binary_mask_visualization(image_np, masks)
        
        # New advanced visualizations
        pipeline_img = generate_pipeline_visualization_img(
            image_np, reasoning, prompt_v1, prompt_v2, boxes_xyxy, clip_scores_final, masks
        )
    else:
        detection_img = image_np.copy()
        mask_img = image_np.copy()
        binary_img = image_np.copy()
        pipeline_img = image_np.copy()
        
    progress(1.0, desc="[OK] Done!")

    # Format agent analysis text
    analysis_text = format_analysis(agent_results, prompt_v1, prompt_v2, len(boxes))

    return detection_img, mask_img, binary_img, pipeline_img, analysis_text

def format_analysis(agent_results, prompt_v1, prompt_v2, num_detections):
    """Format agent analysis for display."""
    lines = []
    lines.append("=" * 60)
    lines.append("[i] DETECTION RESULTS")
    lines.append("=" * 60)
    lines.append(f"[>] Prompt V1: \"{prompt_v1}\"")
    lines.append(f"[>] Prompt V2: \"{prompt_v2}\"")
    lines.append(f"[i] Detections found: {num_detections}")
    lines.append("")

    for i, (name, data) in enumerate([
        ("Agent 1 - Scene Context", agent_results.get("agent1", {})),
        ("Agent 2 - Spatial Anomaly", agent_results.get("agent2", {})),
        ("Agent 3 - Semantic Analysis", agent_results.get("agent3", {})),
        ("Agent 4 - Visual Appearance", agent_results.get("agent4", {})),
        ("Agent 5 - Synthesis", agent_results.get("agent5", {})),
    ]):
        lines.append(f"{'─' * 50}")
        lines.append(f"[i] {name}")
        lines.append(f"{'─' * 50}")
        if isinstance(data, dict):
            if "error" in data:
                lines.append(f"  [FAIL] Error: {data['error'][:100]}")
            else:
                for k, v in data.items():
                    val_str = str(v)
                    if len(val_str) > 150:
                        val_str = val_str[:150] + "..."
                    lines.append(f"  {k}: {val_str}")
        else:
            lines.append(f"  {str(data)[:200]}")
        lines.append("")

    return "\n".join(lines)


# =====================
# Text-Guided Pipeline
# =====================

def process_text_guided(image, user_prompt, clip_threshold, box_threshold, progress=gr.Progress()):
    """Process a text-guided detection request."""
    if image is None:
        return None, None, None, None, None, None, "Please upload an image first."
    if not user_prompt or not user_prompt.strip():
        return None, None, None, None, None, None, "Please enter a text prompt."

    from src.text_guided import run_text_guided_pipeline
    import tempfile

    progress(0.1, desc="Saving image...")
    # Save image to temp file for LLaVA
    temp_path = os.path.join(tempfile.gettempdir(), "tg_input.jpg")
    Image.fromarray(image).save(temp_path)

    progress(0.2, desc="Loading models...")
    gdino = load_gdino_model()
    sam = load_sam_predictor()
    clip_v = load_clip_verifier()
    clip_v.similarity_threshold = clip_threshold

    progress(0.3, desc="Running text-guided pipeline...")
    results = run_text_guided_pipeline(
        image_np=image,
        user_prompt=user_prompt,
        image_path=temp_path,
        gdino_model=gdino,
        sam_predictor=sam,
        clip_verifier=clip_v,
        box_threshold=box_threshold,
        clip_threshold=clip_threshold,
    )

    progress(1.0, desc="Done!")

    steps = results.get("step_images", {})
    return (
        steps.get("step1_scene"),
        steps.get("step2_query"),
        steps.get("step3_candidates"),
        steps.get("step4_clip"),
        steps.get("step5_spatial"),
        steps.get("step6_final"),
        results.get("summary", "No results"),
    )


# =====================
# Batch Pipeline
# =====================
def process_batch(dataset_dir, clip_threshold, box_threshold, progress=gr.Progress()):
    """Process all images in a dataset directory."""
    if not dataset_dir or not os.path.exists(dataset_dir):
        return [], "[FAIL] Dataset directory not found. Check the path."

    img_dir = os.path.join(dataset_dir, "original")
    if not os.path.exists(img_dir):
        img_dir = dataset_dir

    image_files = sorted([
        f for f in os.listdir(img_dir)
        if f.lower().endswith(('.jpg', '.jpeg', '.png'))
    ])

    if not image_files:
        return [], "[FAIL] No images found in the directory."

    progress(0.05, desc="[i] Loading models...")
    gdino = load_gdino_model()
    predictor = load_sam_predictor()
    clip_verifier = load_clip_verifier()

    results_gallery = []
    results_text_lines = []
    results_text_lines.append(f"{'Image':<50} {'Prompt':<30} {'Detections':<12}")
    results_text_lines.append("=" * 92)

    for idx, img_file in enumerate(image_files):
        pct = 0.1 + (0.85 * idx / len(image_files))
        progress(pct, desc=f"Processing {idx+1}/{len(image_files)}: {img_file}")

        img_path = os.path.join(img_dir, img_file)
        image_pil = Image.open(img_path).convert("RGB")
        image_np = np.array(image_pil)

        # Run agents
        try:
            agent_results = run_agents_on_image(img_path)
            prompt_v1, prompt_v2 = extract_prompts(agent_results)
        except Exception as e:
            prompt_v1 = "unusual object on road"
            prompt_v2 = "anomaly"

        # GroundingDINO
        image_tensor = preprocess_image(image_pil)
        boxes, labels, scores = get_grounding_output(
            gdino, image_tensor, prompt_v1,
            box_threshold=box_threshold, text_threshold=0.25
        )

        if len(boxes) == 0 and prompt_v2 != prompt_v1:
            boxes, labels, scores = get_grounding_output(
                gdino, image_tensor, prompt_v2,
                box_threshold=box_threshold, text_threshold=0.25
            )

        # CLIP verification
        if len(boxes) > 0:
            try:
                H_b, W_b = image_np.shape[:2]
                clip_boxes = boxes.clone()
                clip_boxes[:, 0] = (boxes[:, 0] - boxes[:, 2] / 2) * W_b
                clip_boxes[:, 1] = (boxes[:, 1] - boxes[:, 3] / 2) * H_b
                clip_boxes[:, 2] = (boxes[:, 0] + boxes[:, 2] / 2) * W_b
                clip_boxes[:, 3] = (boxes[:, 1] + boxes[:, 3] / 2) * H_b

                clip_verifier.similarity_threshold = clip_threshold
                filtered_boxes, filtered_phrases, _, _ = clip_verifier.verify_detections(
                    image_np, clip_boxes, labels, prompt_v1
                )
                if len(filtered_boxes) > 0:
                    boxes_back = torch.zeros(len(filtered_boxes), 4)
                    boxes_back[:, 0] = ((filtered_boxes[:, 0] + filtered_boxes[:, 2]) / 2) / W_b
                    boxes_back[:, 1] = ((filtered_boxes[:, 1] + filtered_boxes[:, 3]) / 2) / H_b
                    boxes_back[:, 2] = (filtered_boxes[:, 2] - filtered_boxes[:, 0]) / W_b
                    boxes_back[:, 3] = (filtered_boxes[:, 3] - filtered_boxes[:, 1]) / H_b
                    boxes = boxes_back
                    labels = filtered_phrases
            except:
                pass

        # SAM
        if len(boxes) > 0:
            masks, boxes_xyxy = run_sam_segmentation(predictor, image_np, boxes)
            result_img = create_binary_mask_visualization(image_np, masks)
            detection_img = create_detection_visualization(image_np, boxes_xyxy, labels)
        else:
            result_img = image_np.copy()
            detection_img = image_np.copy()

        results_gallery.append((detection_img, f"{img_file} — Detections"))
        results_gallery.append((result_img, f"{img_file} — Mask"))

        results_text_lines.append(
            f"{img_file:<50} {prompt_v1[:28]:<30} {len(boxes):<12}"
        )

    progress(1.0, desc="[OK] Batch complete!")

    summary = "\n".join(results_text_lines)
    summary += f"\n\n[OK] Processed {len(image_files)} images"

    return results_gallery, summary


# =====================
# Gradio UI
# =====================
def build_app():
    """Build the Gradio interface."""

    css = """
    .gradio-container { max-width: 1200px !important; }
    .header { text-align: center; margin-bottom: 20px; }
    """

    with gr.Blocks(
        title="MAVR-OOD: Multi-Agent Vision-Language Reasoning for Reliable Out-of-Distribution Object Localization in Road Environments",
        theme=gr.themes.Soft(primary_hue="blue", secondary_hue="purple"),
        css=css,
    ) as app:

        gr.Markdown("""
        # MAVR-OOD
        ### Multi-Agent Vision-Language Reasoning for Reliable Out-of-Distribution Object Localization in Road Environments
        **Pipeline**: Multi-Agent Analysis (LLaVA-7B) → Object Grounding (GroundingDINO) → Semantic Verification (CLIP) → Segmentation (SAM)
        """)

        with gr.Tabs():
            # ==================
            # Tab 1: Text-Guided Detection
            # ==================
            with gr.TabItem("[i] Text-Guided Detection", id="textguided"):
                gr.Markdown("""Upload any image and describe the object to find. 
                Supports complex queries like **\"the grey car on the left\"** or **\"the largest dog\"**.""")

                with gr.Row():
                    # Left column: Input
                    with gr.Column(scale=1):
                        tg_image = gr.Image(
                            label="Upload Image",
                            type="numpy",
                            height=300,
                        )
                        tg_prompt = gr.Textbox(
                            label="Text Prompt",
                            placeholder='e.g., "the white car on the right"',
                            info="Describe the object. Include spatial terms (left/right/largest) to select one.",
                        )
                        tg_run_btn = gr.Button(
                            "[>>] Detect Object", variant="primary", size="lg"
                        )

                        with gr.Accordion("[*] Advanced Settings", open=False):
                            tg_clip_thresh = gr.Slider(
                                0.05, 0.5, value=0.20, step=0.05,
                                label="CLIP Threshold",
                            )
                            tg_box_thresh = gr.Slider(
                                0.1, 0.5, value=0.25, step=0.05,
                                label="Box Threshold",
                            )

                    # Right column: Step-by-step results
                    with gr.Column(scale=3):
                        with gr.Tabs():
                            with gr.TabItem("Step-by-Step Pipeline"):
                                with gr.Row():
                                    tg_step1 = gr.Image(label="Step 1: Scene Understanding", height=250)
                                    tg_step2 = gr.Image(label="Step 2: Attribute Matching Agent", height=250)
                                    tg_step3 = gr.Image(label="Step 3: Candidates (GDINO)", height=250)
                                with gr.Row():
                                    tg_step4 = gr.Image(label="Step 4: CLIP Verification", height=250)
                                    tg_step5 = gr.Image(label="Step 5: Spatial Filter", height=250)
                                    tg_step6 = gr.Image(label="Step 6: Final Result (SAM)", height=250)

                            with gr.TabItem("Detection Log"):
                                tg_log = gr.Textbox(
                                    label="Pipeline Log",
                                    lines=25,
                                    max_lines=30,
                                )

                tg_run_btn.click(
                    fn=process_text_guided,
                    inputs=[tg_image, tg_prompt, tg_clip_thresh, tg_box_thresh],
                    outputs=[tg_step1, tg_step2, tg_step3, tg_step4, tg_step5, tg_step6, tg_log],
                )

            # ==================
            # Tab 2: OOD Single Image Analysis
            # ==================
            with gr.TabItem("[i] OOD Detection", id="single"):
                gr.Markdown("Upload a road scene image to generate the full analytical dashboard.")

                with gr.Row():
                    # Left column: Input and Controls
                    with gr.Column(scale=1):
                        input_image = gr.Image(
                            label="Upload Road Scene Image",
                            type="numpy",
                            height=350,
                        )
                        run_single_btn = gr.Button(
                            "[>>] Run Advanced Detection", variant="primary", size="lg"
                        )
                        
                        with gr.Accordion("[*] Advanced Tuning Parameters", open=False):
                            clip_thresh = gr.Slider(
                                0.05, 0.5, value=0.20, step=0.05,
                                label="CLIP Verifier Threshold",
                                info="Lower = more detections, Higher = strict true positives",
                            )
                            box_thresh = gr.Slider(
                                0.1, 0.5, value=0.3, step=0.05,
                                label="GroundingDINO Box Threshold",
                                info="Confidence threshold for initial detection",
                            )

                    # Right column: Agent Logs and Output Images
                    with gr.Column(scale=3):
                        with gr.Tabs():
                            with gr.TabItem("[i] Visual Dashboard"):
                                pipeline_output = gr.Image(label="[i] Pipeline Progression (Agent Reasoning -> CLIP -> SAM)", show_download_button=True)
                                
                                with gr.Row():
                                    det_output = gr.Image(label="Bounding Boxes", height=250)
                                    mask_output = gr.Image(label="SAM Masks", height=250)
                                    binary_output = gr.Image(label="Final OOD Mask", height=250)
                                    
                            with gr.TabItem("[i] Agent Logs & Reasoning"):
                                analysis_output = gr.Textbox(
                                    label="Live Agent Synthesis Logs",
                                    lines=35,
                                    max_lines=35,
                                )

                run_single_btn.click(
                    fn=process_single_image,
                    inputs=[input_image, clip_thresh, box_thresh],
                    outputs=[det_output, mask_output, binary_output, pipeline_output, analysis_output],
                )

        gr.Markdown("""
        ---
        **MAVR-OOD** | LLaVA-7B · GroundingDINO · CLIP · SAM
        """)

    return app


# =====================
# Entry Point
# =====================
if __name__ == "__main__":
    # Auto-detect Google Colab
    is_colab = "google.colab" in str(globals().get("get_ipython", lambda: None)())
    
    app = build_app()
    app.launch(
        server_name="0.0.0.0",
        server_port=7860,
        share=is_colab,  # Auto-share on Colab for public URL
        inbrowser=not is_colab,
    )
